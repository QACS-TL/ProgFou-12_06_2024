name = 'fred bloggs'
print(name)

# the backslash character allows string continuation
name = "tina's" \
    'smith'
print(name)

# don't put any additional chars (even if they are spaces after the backslash
name = 'tina' \
    'smith'
print(name)
