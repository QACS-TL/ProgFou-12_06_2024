#       01234567890123456789012345678901234
text = "Remarkable bird, the Norwegian Blue"
print(text[11:14])

print(text[-7:-1])

# Start and end positions may be defaulted
print(text[:14])
print(text[-7:])

#       0123456789012345
text = "Now that's what I call a dead parrot."
print(text[5: 15: 2])

#       0123456789012345
name = "lufesu eb dluoc"
print(name[::-1].upper())
