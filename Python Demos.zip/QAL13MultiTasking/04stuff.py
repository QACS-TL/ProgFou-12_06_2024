ans = input("Enter stuff: ")
print(f"<{ans}>" )
