import time

print("I'm sleepy!")
for i in range(0,5):
    print("ZZZZZZZ")
    time.sleep(1)

print("Hello, I'm awake now!")