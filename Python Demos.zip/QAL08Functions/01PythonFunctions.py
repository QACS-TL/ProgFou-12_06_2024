def make_list(txt, times=2):
   res = str(txt) * times
   return res


mylist = make_list(times=6, txt="banana")
print(mylist)

mylist = make_list("'Ello ", 3)
print(mylist)