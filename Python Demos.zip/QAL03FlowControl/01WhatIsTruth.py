lang = ['Perl', 'Python', 'PHP', 'Ruby']
# lang = []
if lang:
    print("lang contains some stuff")

if 'Python' in lang:
    print('Python is there')

