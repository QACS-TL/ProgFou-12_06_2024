import Finance

newbal = Finance.banking.deposit(100)
print(f"new balance is {newbal}")

