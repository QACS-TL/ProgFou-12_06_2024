class Dog:
    def bark(self, number_of_times):
        for i in range(0, number_of_times):
            print("woof")